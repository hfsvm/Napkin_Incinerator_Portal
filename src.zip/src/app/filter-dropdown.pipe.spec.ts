import { FilterDropdownPipe } from './filter-dropdown.pipe';

describe('FilterDropdownPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterDropdownPipe();
    expect(pipe).toBeTruthy();
  });
});
