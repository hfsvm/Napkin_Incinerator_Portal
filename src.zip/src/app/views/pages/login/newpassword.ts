import { DateFormatter } from "ngx-bootstrap/datepicker";

export interface newotp {
   
    mobileNo:number;
    otp:Number
    newPassword:string;
      }
