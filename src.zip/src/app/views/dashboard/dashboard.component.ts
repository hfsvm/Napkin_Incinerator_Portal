import { Component, OnInit } from '@angular/core';
import { DashboardChartsData, IChartProps } from './dashboard-charts-data';


@Component({
  // templateUrl: 'dashboard.component.html',
  // styleUrls: ['dashboard.component.scss']
})
export class DashboardComponent  {
 

}
