import { FilterMachinePipe } from './filter-machine.pipe';

describe('FilterMachinePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterMachinePipe();
    expect(pipe).toBeTruthy();
  });
});
