export const environment = {
  production: true,

  //dev
    // url:  "http://vmdemo.hfsgroup.in:8080/hfs_edvm/tab",
    // urll: "http://84.247.190.94:8080/hfs_edvm/tab",
    // urlc: "http://vmdemo.hfsgroup.in:8080/hfs_edvm/customer",
    // urla: "http://vmdemo.hfsgroup.in:8080/hfs_edvm/consumer",
    // urlp: "http://vmdemo.hfsgroup.in:8080/hfs_edvm/merchantPortal",
    // urlz:"http://13.235.247.158:8080/hfs_edvm/merchantPortal",
    // urlt:"http://13.235.247.158:8080/hfs_edvm/tab",/
  //   url:  "http://vmdemo.hfsgroup.in:8080/hfs_psvm/tab",
  //   urll: "http://vmdemo.hfsgroup.in:8080/hfs_psvm/tab",
  //   urlc: "http://vmdemo.hfsgroup.in:8080/hfs_psvm/customer",
  //   urla: "http://vmdemo.hfsgroup.in:8080/hfs_psvm/consumer",
  //   urlp: "http://vmdemo.hfsgroup.in:8080/hfs_psvm/merchantPortal",
  //   urlz:"http://vmdemo.hfsgroup.in:8080/hfs_psvm/merchantPortal",
  //   urlt:"http://vmdemo.hfsgroup.in:8080/psvm/tab", 

  //   url1:"http://vmdemo.hfsgroup.in:8080/hfs_psvm/merchantPortal",
  //   url2:"http://vmdemo.hfsgroup.in:8080/hfs_psvm/tab",
  //   urld:"http://vmdemo.hfsgroup.in:8080/hfs_psvm/merchantPortal"
  // //prod
  // url: "http://vmdemo.hfsgroup.in:8080/hfs_vmp/merchantmerchantPortal",
  // urlc: "http://vmdemo.hfsgroup.in:8080/hfs_vmp/customer",
  // urla: "http://vmdemo.hfsgroup.in:8080/hfs_vmp/consumer",

  // url:  "http://vmdemo.hfsgroup.in:8080/hfs_vm/tab",
 
  // urlc: "http://vmdemo.hfsgroup.in:8080/hfs_vm/customer",
  // urla: "http://vmdemo.hfsgroup.in:8080/hfs_vm/consumer",
  // url1:"http://vmdemo.hfsgroup.in:8080/hfs_vm/merchantPortal",
  // urld:"http://vmdemo.hfsgroup.in:8080/hfs_vm/incinerator",

// PROD

   url:  "http://vmdemo.hfsgroup.in:8080/hfs_vm/tab",
 
   urlc: "http://vmdemo.hfsgroup.in:8080/hfs_vm/customer",
   urla: "http://vmdemo.hfsgroup.in:8080/hfs_vm/consumer",
  
   url1:"http://vmprod.hfsgroup.in:8080/hfs_napkinIncinerator/portal",
   urld:"http://vmdemo.hfsgroup.in:8080/hfs_vm/incinerator"

  //UAT
  //  url:  "http://vmuat.hfsgroup.in:8080/hfs_vm/tab",
  //  urlc: "http://vmuat.hfsgroup.in:8080/hfs_vm/customer",
  //  urla: "http://vmuat.hfsgroup.in:8080/hfs_vm/consumer",
  //  url1:"http://vmuat.hfsgroup.in:8080/hfs_napkinIncinerator/portal",
  //  urld:"http://vmuat.hfsgroup.in:8080/hfs_vm/incinerator"

   

};
